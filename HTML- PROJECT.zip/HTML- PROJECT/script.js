
const scrollRevealOption ={
    distance:"50px",
    origin:"bottom",
    duration:1000,
};
ScrollReveal().reveal(".container",scrollRevealOption);
ScrollReveal().reveal(".container",{
  ...scrollRevealOption,
  delay:200,
});
ScrollReveal().reveal(".hero",{
    ...scrollRevealOption,
    delay:300,
  });
  ScrollReveal().reveal(".recipes",scrollRevealOption);
  ScrollReveal().reveal(".recipes",{
    ...scrollRevealOption,
    delay:500,
  });
  ScrollReveal().reveal(".recipes h1",{
    ...scrollRevealOption,
    delay:500,
  });
  ScrollReveal().reveal(".recipe-section",{
    ...scrollRevealOption,
    delay:800,
  });
  ScrollReveal().reveal(".recipe-card",{
    ...scrollRevealOption,
    delay:100,
  });
  ScrollReveal().reveal(".contact",{
    ...scrollRevealOption,
    interval: 500,
  });
  ScrollReveal().reveal(".contact-line",{
    ...scrollRevealOption,
    interval: 500,
    delay: 400,
  });
  ScrollReveal().reveal(".contact-call",{
    interval:400,
    delay:400,
  })
  ScrollReveal().reveal(".contact-email",{
    interval:400,
    delay:300,
  })
  ScrollReveal().reveal(".follow h1",{
    interval:400,
    delay:300,
  })
  ScrollReveal().reveal(".follow ul ",{
    interval:400,
    delay:200,
  })
  ScrollReveal().reveal(".footer",{
    interval:400,
    delay:1000,
  })
  ScrollReveal().reveal(".footer footer",{
    interval:400,
    delay:300,
  })

  ScrollReveal().reveal(".submit",{
    interval:400,
    delay:300,
  })
  ScrollReveal().reveal(".submit h1",{
    interval:400,
    delay:500,
  })
  ScrollReveal().reveal(".recipeform",{
    interval:400,
    delay:800,
  })

  function myfunction() {
    alert("Your Recipe is Submited");
}

function recipe() {
  alert("You are leaving this page")
}

function follow() {
  alert("You are leaving this page")
}

 